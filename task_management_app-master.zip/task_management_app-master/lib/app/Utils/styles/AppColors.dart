import 'package:flutter/material.dart';

class AppColors {
  static const primaryBg = Color(0xFFBFE2FF);
  static const cardBg = Color(0xFFE3E3EE);
  static const primaryText = Color(0xFF808080);
}
